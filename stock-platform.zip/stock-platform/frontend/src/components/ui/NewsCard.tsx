export { NewsCard } from './index';
